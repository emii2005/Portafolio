# Portfolio Personal - Emiliano Méndez

Portfolio minimalista en modo oscuro con cubo Rubik 3D interactivo y estética técnica profesional.

## 🚀 Características

- **Diseño Minimalista**: Estética oscura profesional con tonos negro, gris y blanco
- **Cubo Rubik 3D**: Modelo interactivo completamente negro con acabado brillante
- **Animaciones Suaves**: Efectos de scroll reveal y movimiento con GSAP
- **Responsive Design**: Optimizado para dispositivos móviles y desktop
- **Base de Datos**: PostgreSQL integrada para gestión dinámica de contenido

## 🛠️ Tecnologías

### Frontend
- **HTML5, CSS3, JavaScript ES6+**
- **Three.js** - Renderizado 3D del cubo Rubik
- **GSAP** - Animaciones y efectos de scroll
- **VanillaTilt** - Efectos de inclinación en tarjetas

### Backend & Database
- **PostgreSQL** - Base de datos relacional
- **Drizzle ORM** - Operaciones de base de datos type-safe
- **Node.js** - Entorno de ejecución

### Tipografía
- **Poppins** - Fuente principal moderna y sin serif

## 📁 Estructura del Proyecto

```
/
├── index.html          # Página principal
├── style.css           # Estilos minimalistas
├── script.js           # Lógica 3D y animaciones
├── server/
│   ├── db.ts          # Configuración de base de datos
│   └── storage.ts     # Operaciones CRUD
├── shared/
│   └── schema.ts      # Esquemas de base de datos
└── README.md          # Este archivo
```

## 🎯 Secciones

1. **Hero Fullscreen**: Nombre, descripción y cubo Rubik 3D interactivo
2. **Sobre mí**: Enfoque en diseño visual e interfaces limpias
3. **Objetivo**: Desarrollo frontend y exploración de nuevas ideas
4. **Proyectos**: Tarjetas con efectos 3D (estado "coming soon")
5. **Footer**: Información de contacto y enlace a GitHub

## 🎨 Características Visuales

- Fondo con textura sutil de líneas de código
- Cubo Rubik con materiales metálicos y iluminación realista
- Gradientes de texto y efectos hover elegantes
- Indicador de scroll animado
- Tarjetas de proyectos con efecto tilt

## 📧 Contacto

- **Teléfono**: +54 11 3027 9349
- **Email**: emimenndezz@gmail.com
- **GitHub**: [github.com/emii2005](https://github.com/emii2005)

## 🚀 Desarrollo

```bash
# Clonar el repositorio
git clone https://github.com/emii2005/Portafolio.git

# Abrir en navegador
# Servir con cualquier servidor HTTP local
```

---

*"A veces, las ideas más grandes empiezan como sombras..."*