# Emiliano Méndez - Frontend Developer Portfolio

## Overview

This is a modern, interactive personal portfolio website for Emiliano Méndez, a frontend developer. The site features a sophisticated dark theme with 3D animations, smooth scrolling effects, and interactive elements. It's built using vanilla HTML, CSS, and JavaScript with several external libraries for enhanced visual effects. **Database functionality has been integrated** for future dynamic content management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Pure Frontend Application**: Single-page application built with vanilla HTML, CSS, and JavaScript
- **Database Integration**: PostgreSQL database with Drizzle ORM for data persistence and future dynamic features
- **Library-Based Approach**: Uses external CDN libraries rather than a build system or package manager
- **Component-Style CSS**: Organized with CSS custom properties and modular styling approach

### Database Architecture
- **PostgreSQL Database**: Relational database for storing portfolio data
- **Drizzle ORM**: Type-safe database operations with TypeScript
- **Tables**: users, messages, projects, skills with proper relations
- **Environment**: Database credentials stored in environment variables

### Technology Stack
- **Core Technologies**: HTML5, CSS3, ES6+ JavaScript
- **3D Graphics**: Three.js (r128) for 3D cube animations and WebGL rendering
- **Animations**: GSAP (GreenSock) with ScrollTrigger plugin for smooth scroll-based animations
- **Interactive Effects**: VanillaTilt for tilt effects on elements
- **Typography**: Google Fonts (Poppins) for modern typography
- **Controls**: Three.js OrbitControls for 3D scene interaction
- **Database**: PostgreSQL with Drizzle ORM for data persistence
- **Backend Integration**: Node.js compatible database layer

## Key Components

### 1. Hero Section
- **Purpose**: Main landing area with developer introduction
- **Features**: 3D interactive Rubik's cube, animated text, scroll indicator
- **3D Implementation**: WebGL-based cube with realistic lighting and shadows

### 2. About Section
- **Purpose**: Personal introduction and professional focus
- **Design**: Clean typography with scroll-triggered animations

### 3. Three.js 3D Scene
- **Cube Rendering**: Interactive 3D Rubik's cube with realistic materials
- **Lighting System**: Combination of ambient, directional, and point lights
- **Controls**: Orbit controls for user interaction (rotation only, no zoom/pan)
- **Performance**: Optimized with proper pixel ratio and shadow mapping

### 4. CSS Architecture
- **Design System**: CSS custom properties for consistent theming
- **Color Scheme**: Sophisticated dark theme with gradients
- **Responsive Design**: Mobile-first approach with fluid layouts
- **Animation System**: CSS transitions combined with GSAP for complex animations

## Data Flow

### Static Content Flow
1. **Initial Load**: Browser loads HTML structure and external libraries
2. **Style Application**: CSS processes custom properties and applies dark theme
3. **JavaScript Initialization**: Three.js scene setup and GSAP animation registration
4. **3D Rendering**: Continuous render loop for 3D cube animation
5. **Scroll Interactions**: ScrollTrigger manages scroll-based animations

### User Interaction Flow
1. **Page Load**: Automatic animations trigger on content load
2. **Scroll Events**: ScrollTrigger detects scroll position and triggers animations
3. **3D Interaction**: OrbitControls handle mouse/touch input for cube rotation
4. **Tilt Effects**: VanillaTilt responds to mouse movement for card interactions

## External Dependencies

### CDN Libraries
- **Three.js**: 3D graphics rendering and WebGL abstraction
- **GSAP**: Professional-grade animation library with ScrollTrigger
- **VanillaTilt**: Lightweight tilt effect library
- **Google Fonts**: Poppins font family for typography

### Design Assets
- **Typography**: Google Fonts API for consistent font loading
- **Icons**: None currently, but structure supports future addition
- **Images**: No external images, all effects are code-generated

## Deployment Strategy

### Static Hosting Compatible
- **No Build Process**: Can be deployed directly to any static hosting service
- **CDN Friendly**: All dependencies loaded from CDNs, reducing bundle size
- **Deployment Options**: 
  - GitHub Pages
  - Netlify
  - Vercel
  - Traditional web hosting
  - Replit static hosting

### Performance Considerations
- **Library Loading**: All libraries loaded from CDNs for caching benefits
- **3D Optimization**: Proper pixel ratio handling and shadow optimization
- **Animation Performance**: GSAP provides hardware-accelerated animations
- **Responsive Design**: Optimized for various screen sizes and devices

### Browser Compatibility
- **Modern Browsers**: Requires WebGL support for 3D features
- **Progressive Enhancement**: Core content accessible even if 3D fails
- **Mobile Optimization**: Touch-friendly interactions and responsive design

## Development Notes

### File Structure
- `index.html`: Main HTML structure with semantic sections
- `style.css`: Complete styling with CSS custom properties and responsive design
- `script.js`: JavaScript for Three.js scene setup and animations

### Extensibility
- **Modular CSS**: Easy to add new sections or modify existing styles
- **Component Structure**: Well-organized for adding new interactive elements
- **Animation Framework**: GSAP setup allows for easy addition of new animations
- **3D Scene**: Three.js setup can accommodate additional 3D elements

### Future Enhancements
- Additional portfolio sections (projects, skills, contact)
- More complex 3D interactions or animations
- Contact form integration
- Blog or content management system integration
- Performance monitoring and analytics